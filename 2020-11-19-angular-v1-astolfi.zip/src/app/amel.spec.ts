import { Amel } from './amel';

describe('Amel', () => {
  it('should create an instance', () => {
    expect(new Amel()).toBeTruthy();
  });
});
