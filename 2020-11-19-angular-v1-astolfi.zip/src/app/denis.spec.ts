import { Denis } from './denis';

describe('Denis', () => {
  it('should create an instance', () => {
    expect(new Denis()).toBeTruthy();
  });
});
