import { Michele } from './michele';

describe('Michele', () => {
  it('should create an instance', () => {
    expect(new Michele()).toBeTruthy();
  });
});
