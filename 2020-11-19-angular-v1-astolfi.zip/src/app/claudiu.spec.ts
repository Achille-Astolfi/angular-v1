import { Claudiu } from './claudiu';

describe('Claudiu', () => {
  it('should create an instance', () => {
    expect(new Claudiu()).toBeTruthy();
  });
});
