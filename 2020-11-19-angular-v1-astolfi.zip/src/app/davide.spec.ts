import { Davide } from './davide';

describe('Davide', () => {
  it('should create an instance', () => {
    expect(new Davide()).toBeTruthy();
  });
});
