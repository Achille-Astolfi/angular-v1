export class Denis {
}
