import { Vittorio } from './vittorio';

describe('Vittorio', () => {
  it('should create an instance', () => {
    expect(new Vittorio()).toBeTruthy();
  });
});
