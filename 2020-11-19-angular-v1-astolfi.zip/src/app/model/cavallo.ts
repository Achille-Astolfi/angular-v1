export class Cavallo {
}
