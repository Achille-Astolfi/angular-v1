import { Cavallo } from './cavallo';

describe('Cavallo', () => {
  it('should create an instance', () => {
    expect(new Cavallo()).toBeTruthy();
  });
});
