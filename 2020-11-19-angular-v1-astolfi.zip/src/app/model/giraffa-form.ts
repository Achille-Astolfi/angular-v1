export class GiraffaForm {
}
