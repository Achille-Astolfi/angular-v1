import { GiraffaForm } from './giraffa-form';

describe('GiraffaForm', () => {
  it('should create an instance', () => {
    expect(new GiraffaForm()).toBeTruthy();
  });
});
