import { Eliana } from './eliana';

describe('Eliana', () => {
  it('should create an instance', () => {
    expect(new Eliana()).toBeTruthy();
  });
});
