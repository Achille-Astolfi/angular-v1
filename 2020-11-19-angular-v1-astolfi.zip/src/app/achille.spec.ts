import { Achille } from './achille';

describe('Achille', () => {
  it('should create an instance', () => {
    expect(new Achille()).toBeTruthy();
  });
});
